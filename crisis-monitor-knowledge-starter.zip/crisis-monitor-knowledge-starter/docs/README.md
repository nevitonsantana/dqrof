# Docs

Esta pasta guarda conhecimento de longa duração.

## Subpastas

- `playbooks/`: método, operação, critérios e aplicação ao projeto
- `packs/`: conhecimento de domínio e contratos/artefatos de projeto

## Regra

Se um documento descreve como trabalhar, decidir, validar ou governar, ele tende a morar aqui.
