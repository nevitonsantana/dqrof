# Crisis Monitor Pack

Artefatos de projeto com valor estrutural.

## Sugestões de arquivos

- `briefing.schema.json`
- `keyword-suggestion.schema.json`
- `monitoring-milestone.schema.json`
- `monitoring-workflows.md`
- `monitoring-core-prd.md`
- `monitoring-core-roadmap.md`

## Observação

Se o artefato define contrato, estrutura ou modelo semântico, ele tende a morar aqui.
