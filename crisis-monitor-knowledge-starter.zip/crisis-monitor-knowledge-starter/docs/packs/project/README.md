# Project Packs

Contratos, schemas e artefatos de projeto.

Exemplos:
- schemas JSON
- workflows
- PRDs-base
- roadmap
- contratos de entidades
