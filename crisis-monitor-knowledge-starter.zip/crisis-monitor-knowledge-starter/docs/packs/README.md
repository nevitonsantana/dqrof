# Packs

Packs reúnem artefatos de apoio: glossário, taxonomia, schemas, contratos e fluxos.

## Tipos

- `domain/`: conhecimento reaproveitável por tipo de problema
- `project/`: contratos e artefatos locais do projeto
