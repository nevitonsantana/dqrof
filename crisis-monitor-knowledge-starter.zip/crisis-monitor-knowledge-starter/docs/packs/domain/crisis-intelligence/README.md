# Crisis Intelligence Pack

Pack de domínio para projetos de inteligência, monitoramento e gestão de crise.

## Sugestões de arquivos

- `glossary.md`
- `risk-taxonomy.md`
- `communication-model.md`
- `evaluation-criteria.md`

## Regra

Este pack deve abstrair o domínio sem depender demais do Crisis Monitor.
