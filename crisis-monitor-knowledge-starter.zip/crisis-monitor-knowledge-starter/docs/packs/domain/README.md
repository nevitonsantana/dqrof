# Domain Packs

Conhecimento do domínio em formato mais estrutural do que narrativo.

Exemplos:
- glossário
- taxonomia de risco
- modelo de comunicação
- critérios de avaliação
