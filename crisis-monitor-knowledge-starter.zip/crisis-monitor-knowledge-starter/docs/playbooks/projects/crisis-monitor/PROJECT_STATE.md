# PROJECT_STATE

> Stub

Migrar conteúdo de `PROJECT_STATE.md`.
