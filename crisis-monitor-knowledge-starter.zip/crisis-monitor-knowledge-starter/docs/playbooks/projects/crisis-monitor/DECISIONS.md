# DECISIONS

> Stub

Migrar conteúdo de `DECISIONS.md`.
