# Crisis Monitor — Playbooks de Projeto

Pasta do projeto específico.

## Arquivos candidatos a viver aqui

- `AI-DLC-Playbook-Crisis-Monitor.md`
- `ARCHITECTURE.md`
- `DECISIONS.md`
- `PROJECT_STATE.md`
- `semantic-model.md`
- `test-plan.md`

## Função

Concentrar as regras e decisões que só fazem sentido dentro do Crisis Monitor.
