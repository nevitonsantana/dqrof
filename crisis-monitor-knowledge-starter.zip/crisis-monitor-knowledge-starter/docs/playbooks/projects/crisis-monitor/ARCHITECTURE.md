# ARCHITECTURE

> Stub

Migrar conteúdo de `ARCHITECTURE.md`.
