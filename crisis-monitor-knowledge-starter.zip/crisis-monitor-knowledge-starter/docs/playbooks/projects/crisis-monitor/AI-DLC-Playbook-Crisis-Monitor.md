# AI-DLC Playbook — Crisis Monitor

> Stub

Substituir este arquivo pelo conteúdo de `AI-DLC-Playbook-Crisis-Monitor-v1.md`.
