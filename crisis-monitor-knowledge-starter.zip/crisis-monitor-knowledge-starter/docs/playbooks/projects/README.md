# Project Playbooks

Aplicação concreta do método a cada projeto.

Cada projeto deve ter sua própria pasta e apontar para:

- arquitetura
- decisões acumuladas
- estado atual
- playbook local
- modelos semânticos e critérios específicos
