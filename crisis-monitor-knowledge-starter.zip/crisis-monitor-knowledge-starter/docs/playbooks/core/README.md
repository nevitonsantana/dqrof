# Core Playbooks

Método-base reutilizável entre projetos.

## Coloque aqui

- AI-DLC core
- matriz de severidade de mudança
- template de handoff de thread
- guardrails de release
- critérios mínimos de aprovação e validação

## Não coloque aqui

- linguagem específica de crise
- detalhes de arquitetura local
- backlog ou estado do projeto
