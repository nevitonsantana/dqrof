# AI-DLC Core Playbook

> Stub

Substituir este arquivo pelo conteúdo de `AI-DLC-Core-Playbook-v1.md`.
