# Change Severity Matrix

> Stub

Substituir este arquivo pelo conteúdo de `CHANGE-SEVERITY-MATRIX.md`.
