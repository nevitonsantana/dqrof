# Playbooks

Playbooks são documentos operacionais. Eles explicam como trabalhar, validar, liberar e manter qualidade.

## Camadas

- `core/`: método reutilizável
- `domain/`: regras do tipo de problema
- `projects/`: adaptação do método ao projeto

## Critério

Um playbook não deve duplicar detalhes de feature. Ele deve apontar para contratos, packs e docs específicos.
