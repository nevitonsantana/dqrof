# Domain Playbooks

Regras e critérios do tipo de problema.

## Coloque aqui

- linguagem e taxonomia do domínio
- critérios de explicabilidade
- padrões de UX para sistemas sensíveis
- semântica de risco
- comunicação institucional e operacional
