# Threads

Memória operacional curta, mas durável.

## Uso

- registrar handoff ao encerrar uma thread relevante
- reabrir contexto sem depender de histórico do chat
- apontar decisões locais, arquivos afetados, riscos e próximos passos

## Regra

Thread não substitui `PROJECT_STATE.md` nem `DECISIONS.md`.
Ela complementa.
