# Domain Skills

## Candidatas imediatas

- `ux-strategy.md`
- `ux-provocation.md`
- `ux-heuristic-audit.md`
- `crisis-content-design-full.md`
- `crisis-content-design-lite.md`

## Papel

Trazer criticidade, linguagem e critérios do domínio sem acoplar ao projeto local.
