# crisis-content-design-lite

> Stub

Migrar conteúdo de `crisis-ux-writing-skill/SKILL-LITE.md`.
