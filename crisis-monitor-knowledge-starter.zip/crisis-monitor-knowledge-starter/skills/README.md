# Skills

Skills são instruções operacionais reutilizáveis para orientar a IA em tarefas recorrentes.

## Camadas

- `core/`: funciona em quase qualquer projeto
- `domain/`: depende do tipo de problema
- `project/`: depende do contexto do projeto

## Critério para promover a skill

Promova quando a lógica:
- reaparece em múltiplas threads
- é estável
- evita erro recorrente
- cabe em instrução curta/modular
