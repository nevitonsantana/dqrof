# workflow

> Stub

Migrar conteúdo de `workflow.md`.
