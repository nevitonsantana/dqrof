# testing

> Stub

Migrar conteúdo de `testing.md`.
