# Core Skills

## Candidatas imediatas

- `workflow.md`
- `communication.md`
- `code-style.md`
- `testing.md`
- `feature-planning.md`
- `thread-checklist.md`

## Papel

Disciplinar execução, contexto, teste e comunicação independentemente do domínio.
