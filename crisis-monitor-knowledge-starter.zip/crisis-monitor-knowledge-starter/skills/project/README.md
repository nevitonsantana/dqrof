# Project Skills

Skills locais do projeto.

Regra prática: se a instrução depende do modelo semântico, das entidades, dos fluxos ou da assistente do projeto, ela tende a viver aqui.
