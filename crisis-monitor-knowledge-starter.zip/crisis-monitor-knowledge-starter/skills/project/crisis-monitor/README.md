# Crisis Monitor Skills

## Candidatas iniciais

- `cris-assistant.md`
- `monitoring-core.md`
- `keyword-groups.md`
- `media-tiers.md`
- `public-crisis-management.md`
- `briefing-review.md`

## Ainda em doc/feature

- pilotos muito experimentais
- contratos arquiteturais em evolução
- benchmarks e spikes técnicos
