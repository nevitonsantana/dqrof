# cris-assistant

> Stub

Extrair a versão consolidada a partir de `FEATURE_cris-skills-architecture.md`, `FEATURE_cris-skills-phase0-contracts.md` e docs correlatas.
