# Evals

Centraliza suites de avaliação e regressão.

## Sugestões

- `semantic-evals.md`
- `regression-evals.md`
- `security-evals.md`
- `ux-evals.md`

## Função

Garantir que mudanças técnicas, semânticas e operacionais sejam avaliadas de forma repetível.
