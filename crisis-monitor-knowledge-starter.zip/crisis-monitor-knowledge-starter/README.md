# Knowledge Starter Kit

Estrutura inicial para organizar playbooks, packs, skills, features, threads e evals.

## Objetivo

Servir como ponto de partida para migrar o acervo atual para uma arquitetura mais modular, com separação entre:

- `core`: método reutilizável
- `domain`: regras e linguagem do tipo de problema
- `project`: contexto específico do projeto

## Ordem de adoção recomendada

1. Migrar `PROJECT_STATE.md`, `DECISIONS.md` e `ARCHITECTURE.md`
2. Migrar `AI-DLC Core Playbook`, `Thread Handoff Template` e `Change Severity Matrix`
3. Consolidar `skills/core`
4. Consolidar `skills/domain`
5. Promover apenas as skills de projeto que tenham uso recorrente e escopo estável

## Regras simples

- Chat não é memória do projeto
- Toda feature relevante precisa de contrato
- Toda thread relevante precisa de handoff
- Toda mudança deve ter severidade classificada
- Toda regra deve viver em um único lugar de verdade
