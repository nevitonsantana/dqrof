# FEATURE_TEMPLATE

> Stub

Migrar conteúdo de `FEATURE_TEMPLATE.md`.
