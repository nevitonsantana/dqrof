# Features

Features são contratos de mudança.

Toda feature deve apontar para:
- problema
- objetivo
- impacto
- riscos
- critérios de aceite
- docs relacionados
- handoff quando aplicável
