# Crisis Monitor Features

Pasta para contratos de feature do projeto.

## Base sugerida

- `FEATURE_INDEX.md`
- `FEATURE_TEMPLATE.md`
- features por frente funcional

## Regra

Se a frente ainda depende de descoberta local e precisa de critérios próprios, continue como feature doc antes de virar skill.
