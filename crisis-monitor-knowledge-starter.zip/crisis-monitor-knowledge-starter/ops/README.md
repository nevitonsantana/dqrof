# Ops

Registros operacionais e checks de execução.

## Sugestões

- `approvals.md`
- `release-checks.md`
- `incident-notes.md`

## Função

Separar operação e governança leve de documentação conceitual.
